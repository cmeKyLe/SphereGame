using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class CoinCounter : MonoBehaviour
{
   public static CoinCounter instance;

    public TextMeshProUGUI coinText;
    

   void Awake()
    {
        instance = this;
    }



    // Start is called before the first frame update
    void Start()
    {
        coinText.text = "COINS: 0";
    }

    // Update is called once per frame
    //void Update()
    //{

    //}


    public void IncreaseCoins(int v) { 
        
        coinText.text="COINS: "+ v;
    }
}
