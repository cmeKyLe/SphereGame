using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;


//Sphere Player object
public class Player : MonoBehaviour
{
    
    [SerializeField] private LayerMask playerMask;
    private bool jumpKeyWasPressed;
    private float horizontalInput;
    private Rigidbody rigidBodyComponent;
    private bool isGrounded;
    public int coinScore;
    //Access start/end to end the game
    private Start_End gameEnd;
   


    // Start is called before the first frame update
    void Start()
    {
        //reference to ridged body component
        rigidBodyComponent = GetComponent<Rigidbody>();
        //reference to start end script
        gameEnd = GameObject.FindAnyObjectByType<Start_End>();
    }

    // Update is called once per frame
    //check for key presses in the update loop
    void Update()
    {
     
        //check if space key is pressed down
        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumpKeyWasPressed = true;
        }

        horizontalInput = Input.GetAxis("Horizontal");

        if (this.gameObject.transform.position.y <= -5)
        {

            gameEnd.EndOn();
            rigidBodyComponent.constraints = RigidbodyConstraints.FreezePositionY;
        }
    }

    

    //FixedUpdate is called once every physics update
    // perform the required action in the Fixed update loop
    void FixedUpdate()
    {
        rigidBodyComponent.velocity = new Vector3(horizontalInput*3, rigidBodyComponent.velocity.y, 0);

        if (!isGrounded) {
            return;
        }

        if (jumpKeyWasPressed)
        {
            rigidBodyComponent.AddForce(Vector3.up * 5, ForceMode.Impulse);
            //if you dont set it to false, the player shoots up continuously
            jumpKeyWasPressed = false;
        }


    }


    private void OnCollisionEnter(Collision collision)
    {
        isGrounded = true;
    }
    void OnCollisionExit(Collision collision)
    {
        isGrounded = false;
    }
    void OnTriggerEnter(Collider other)
    {
        //coin layer == 7
        if (other.gameObject.layer == 7) {
            Destroy(other.gameObject);
            //increment coin score
            coinScore++;
            Debug.Log("Coin Score: "+ coinScore);
            //call method that displays the updated score. Score should be  an argument

            CoinCounter.instance.IncreaseCoins(coinScore);
        }
        //layer 8== enemy
        if (other.gameObject.layer == 8) {
            gameEnd.EndOn();
            Debug.Log("Game over");
        }
    }



}
