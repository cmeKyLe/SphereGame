using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Start_End : MonoBehaviour
{
    [SerializeField] private GameObject EndScreen;
    [SerializeField] private GameObject StartScreen;
    Player player;
    // Start is called before the first frame update
    void Start()
    {

        StartScreen.SetActive(true);
        EndScreen.SetActive(false); 
        player = GameObject.FindAnyObjectByType<Player>();
        player.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void StartOff ()
    {

        StartScreen.SetActive(false);
        player.enabled=true;
    }
    public void EndOn()
    {
        EndScreen.SetActive(true);
        player.enabled=false;
    }

    // to restart
    public void restart ()
    {

        SceneManager.LoadScene("SampleScene");
    }

}
